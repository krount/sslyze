
__author__ = 'Alban Diquet'
__license__ = 'GPLv2'
__version__ = '1.1.1'
__email__ = 'nabla.c0d3@gmail.com'
PROJECT_URL = 'https://github.com/nabla-c0d3/sslyze'
PROJECT_DESC = 'Fast and full-featured SSL scanner.'
